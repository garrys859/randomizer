// Claves para localStorage
const KEY_PLAYLIST = "myrnd-playlist"; // Para JSON comprimido
const KEY_IDX      = "myrnd-idx";      // Índice actual
const KEY_PID      = "myrnd-pid";      // IDs guardados

let videos = [];
let currentIndex = 0;
let player = null; // Instancia de la IFrame Player (para evitar video no disponible en youtube)

// URL de tu back-end en Render (o donde esté tu servidor Node)
const baseURL = "https://randomizer-cg53.onrender.com";

document.addEventListener("DOMContentLoaded", () => {
  console.log("DOM completamente cargado.");

  const loadBtn = document.getElementById("loadBtn");
  const resumeBtn = document.getElementById("resumeBtn");

  if (localStorage.getItem(KEY_PLAYLIST) && localStorage.getItem(KEY_IDX) && localStorage.getItem(KEY_PID)) {
    console.log("Sesión previa detectada en localStorage.");
    resumeBtn.classList.remove("hidden");
  }

  loadBtn.addEventListener("click", () => {
    const pidInput = document.getElementById("playlistId").value.trim();
    console.log("Cargar Playlist presionado. ID/URL introducido:", pidInput);
    if (!pidInput) {
      alert("Ingresa un ID de playlist o una URL válida de YouTube.");
      return;
    }
    loadPlaylist(pidInput);
  });

  resumeBtn.addEventListener("click", () => {
    console.log("Retomar sesión anterior.");
    resumeSession();
  });

  document.getElementById("prevBtn").addEventListener("click", () => {
    console.log("Reproducir video anterior.");
    playVideoAtIndex(currentIndex - 1);
  });

  document.getElementById("nextBtn").addEventListener("click", () => {
    console.log("Reproducir video siguiente.");
    playVideoAtIndex(currentIndex + 1);
  });

  const searchInput = document.getElementById("searchInput");
  const searchResults = document.getElementById("searchResults");

  searchInput.addEventListener("input", () => {
    const query = searchInput.value.trim();
    console.log("Entrada en barra de búsqueda:", query);
    searchResults.innerHTML = "";

    if (query.length === 0) {
      console.log("No se ingresó término de búsqueda. Mostrando toda la lista.");
      fillSearchResults(videos);
      return;
    }

    const results = idxSearch(query);
    console.log("Resultados de búsqueda:", results);
    const filteredVideos = results.map(r => videos[parseInt(r.ref, 10)]);
    fillSearchResults(filteredVideos);
  });

  searchResults.addEventListener("change", () => {
    const val = parseInt(searchResults.value, 10);
    console.log("Video seleccionado desde los resultados de búsqueda:", val);
    if (!isNaN(val)) {
      playVideoAtIndex(val);
    }
  });
});

function getPlaylistIdFromUrl(urlOrId) {
  try {
    if (!urlOrId.includes("youtube.com")) {
      return urlOrId;
    }
    const url = new URL(urlOrId);
    return url.searchParams.get("list");
  } catch (error) {
    console.error("Error al extraer el ID de la playlist:", error);
    return urlOrId;
  }
}

async function loadPlaylist(pidInput) {
  try {
    const playlistId = getPlaylistIdFromUrl(pidInput);
    console.log("Playlist ID extraído:", playlistId);

    const url = `${baseURL}/api/playlist?playlistId=${encodeURIComponent(playlistId)}`;
    console.log("URL para cargar la playlist:", url);

    const resp = await fetch(url);
    if (!resp.ok) {
      console.error("Error al contactar con el servidor:", resp.status);
      alert("Error al contactar con el servidor");
      return;
    }

    const data = await resp.json();
    console.log("Datos recibidos del servidor:", data);

    if (data.status !== 200) {
      console.error("Error en la respuesta del servidor:", data);
      alert("No se pudo cargar la playlist");
      return;
    }

    videos = data.response;
    console.log("Videos cargados:", videos);

    shuffleArray(videos);

    currentIndex = 0;
    saveSession(pidInput);

    document.getElementById("playerArea").classList.remove("hidden");
    fillPlaylistView();
    buildIndexIfNeeded(true);

    if (!player) {
      console.log("Inicializando reproductor de YouTube.");
      createPlayerIfNeeded(() => {
        console.log("Reproductor inicializado, reproduciendo video inicial.");
        playVideoAtIndex(currentIndex);
      });
    } else {
      playVideoAtIndex(currentIndex);
    }

  } catch (err) {
    console.error("Error al cargar la playlist:", err);
    alert("Ocurrió un error al obtener la playlist");
  }
}

function fillPlaylistView() {
  const sel = document.getElementById("playlistView");
  sel.innerHTML = "";
  console.log("Rellenando lista de reproducción en el DOM.");
  videos.forEach((vid, idx) => {
    const opt = document.createElement("option");
    opt.value = idx;
    opt.textContent = `(${idx}) ${vid.title}`;
    sel.appendChild(opt);
  });
  sel.classList.remove("hidden");
}

function fillSearchResults(results) {
  const searchResults = document.getElementById("searchResults");
  searchResults.innerHTML = "";
  console.log("Rellenando resultados de búsqueda:", results);
  results.forEach((vid, idx) => {
    const opt = document.createElement("option");
    opt.value = videos.indexOf(vid);
    opt.textContent = `(${videos.indexOf(vid)}) ${vid.title}`;
    searchResults.appendChild(opt);
  });
  searchResults.size = Math.min(results.length, 8);
  searchResults.classList.remove("hidden");
}

function saveSession(pid) {
  console.log("Guardando sesión en localStorage.");
  const comp = LZString.compressToUTF16(JSON.stringify(videos));
  localStorage.setItem(KEY_PLAYLIST, comp);
  localStorage.setItem(KEY_IDX, currentIndex.toString());
  localStorage.setItem(KEY_PID, pid);
}

function resumeSession() {
  console.log("Retomando sesión desde localStorage.");
  const comp = localStorage.getItem(KEY_PLAYLIST);
  videos = JSON.parse(LZString.decompressFromUTF16(comp));
  console.log("Videos restaurados:", videos);
  currentIndex = parseInt(localStorage.getItem(KEY_IDX), 10) || 0;

  document.getElementById("playerArea").classList.remove("hidden");
  fillPlaylistView();
  buildIndexIfNeeded();

  if (!player) {
    console.log("Inicializando reproductor de YouTube.");
    createPlayerIfNeeded(() => {
      console.log("Reproductor inicializado, retomando video en índice:", currentIndex);
      playVideoAtIndex(currentIndex);
    });
  } else {
    playVideoAtIndex(currentIndex);
  }
}

function createPlayerIfNeeded(callback) {
  if (window.YT && window.YT.Player) {
    if (!player) {
      createIframePlayer(callback);
    } else if (callback) {
      callback();
    }
  } else {
    const tag = document.createElement("script");
    tag.src = "https://www.youtube.com/iframe_api";
    document.body.appendChild(tag);

    window.onYouTubeIframeAPIReady = () => {
      createIframePlayer(callback);
    };
  }
}

function createIframePlayer(callback) {
  console.log("Creando reproductor de YouTube.");
  player = new YT.Player("iframe-container", {
    width: "640",
    height: "360",
    videoId: (videos[0]?.id) || "dQw4w9WgXcQ",
    playerVars: {
      autoplay: 1,
      controls: 1,
      rel: 0
    },
    events: {
      onReady: (event) => {
        console.log("Reproductor listo, reproduciendo video inicial.");
        event.target.playVideo();
        updateTitleAndProgress();
        if (callback) callback();
      },
      onError: (event) => {
        console.error("Error en el reproductor de YouTube, saltando al siguiente video:", event);
        setTimeout(() => {
          playVideoAtIndex(currentIndex + 1);
        }, 2000);
      },
      onStateChange: (event) => {
        if (event.data === YT.PlayerState.ENDED) {
          console.log("Video terminado, reproduciendo el siguiente.");
          playVideoAtIndex(currentIndex + 1);
        }
      }
    }
  });
}

function playVideoAtIndex(idx) {
  if (!videos || videos.length === 0) return;

  console.log("Reproduciendo video en índice:", idx);

  if (idx < 0) idx = videos.length - 1;
  if (idx >= videos.length) idx = 0;

  currentIndex = idx;
  document.getElementById("playlistView").value = idx;

  const video = videos[idx];
  if (video && player && player.loadVideoById) {
    const videoId = video.id;
    console.log("Cargando video en el reproductor:", videoId);
    player.loadVideoById(videoId);
    updateTitleAndProgress();
  } else {
    console.error("Video no encontrado o reproductor no inicializado.");
  }

  localStorage.setItem(KEY_IDX, currentIndex.toString());
}

function shuffleArray(arr) {
  console.log("Mezclando videos.");
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
}

let elasticIndex = null;
function buildIndexIfNeeded(forceRebuild = false) {
  if (!elasticIndex || forceRebuild) {
    console.log("Construyendo índice de búsqueda.");
    elasticIndex = elasticlunr(function() {
      this.setRef("idx");
      this.addField("title");
    });
    videos.forEach((v, i) => {
      elasticIndex.addDoc({ idx: i, title: v.title });
    });
  }
}

function idxSearch(query) {
  console.log("Realizando búsqueda con término:", query);
  buildIndexIfNeeded();
  const results = elasticIndex.search(query, { bool: "AND", expand: true });
  console.log("Resultados encontrados:", results);
  return results;
}

function updateTitleAndProgress() {
  if (!player || !videos[currentIndex]) return;

  const videoTitle = videos[currentIndex].title || "Título no disponible";
  const totalVideos = videos.length;
  const currentVideoNumber = currentIndex + 1;

  // Limpia cualquier intervalo previo
  if (window.titleUpdateInterval) clearInterval(window.titleUpdateInterval);

  window.titleUpdateInterval = setInterval(() => {
    if (player.getPlayerState() === YT.PlayerState.PLAYING) {
      const currentTime = player.getCurrentTime() || 0;
      const duration = player.getDuration() || 1; // Evita división por cero
      const progress = ((currentTime / duration) * 100).toFixed(2);

      document.title = `Song Progress: ${progress}% of "${videoTitle}" ~ (${currentVideoNumber}/${totalVideos}) of playlist.`;
    }
  }, 1000);
}
